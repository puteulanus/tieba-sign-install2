<?php
if(!defined('IN_KKFRAME')) exit();
?>
<h2>签到记录</h2>
<span id="page-flip" class="float-right"></span>
<p id="sign-stat"></p>
<table>
<thead><tr><td style="width: 40px">#</td><td>贴吧</td><td class="mobile_min">状态</td><td class="mobile_min">经验</td></tr></thead>
<tbody></tbody>
</table>